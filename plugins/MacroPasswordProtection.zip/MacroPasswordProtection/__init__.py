def classFactory(iface):
    from .MacroPasswordProtection import MacroPasswordProtectionPlugin
    return MacroPasswordProtectionPlugin(iface)