from qgis.core import QgsProject
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (QAction, QDialog, QVBoxLayout, QLabel, 
                                 QLineEdit, QPushButton, QHBoxLayout)
from qgis.PyQt.QtCore import Qt

class InjectionDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("MacroPasswordProtection")
        self.setFixedWidth(400)
        
        layout = QVBoxLayout()

        # 1. The Question
        self.label = QLabel("Do you want to add Password Protection for the\nAttribute Forms to this file?")
        self.label.setWordWrap(True)
        self.label.setStyleSheet("font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(self.label)

        # 2. Password Field
        layout.addWidget(QLabel("Set Password:"))
        self.pwd_input = QLineEdit()
        self.pwd_input.setEchoMode(QLineEdit.Password)
        self.pwd_input.setPlaceholderText("Enter password here...")
        layout.addWidget(self.pwd_input)

        # 3. Feedback Label (Invisible until used)
        self.feedback = QLabel("")
        self.feedback.setStyleSheet("margin-top: 10px;")
        layout.addWidget(self.feedback)

        # 4. Buttons
        btn_layout = QHBoxLayout()
        self.apply_btn = QPushButton("Apply Protection")
        self.close_btn = QPushButton("Close")
        btn_layout.addWidget(self.apply_btn)
        btn_layout.addWidget(self.close_btn)
        layout.addLayout(btn_layout)

        self.setLayout(layout)

class MacroPasswordProtectionPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        icon = QIcon(":/images/themes/default/mActionAdd.svg")
        self.action = QAction(icon, "Add Password Protection", self.iface.mainWindow())
        self.action.triggered.connect(self.show_dialog)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)

    def show_dialog(self):
        self.dlg = InjectionDialog(self.iface.mainWindow())
        self.dlg.apply_btn.clicked.connect(self.process_injection)
        self.dlg.close_btn.clicked.connect(self.dlg.close)
        self.dlg.exec_()

    def process_injection(self):
        pwd = self.dlg.pwd_input.text()
        
        if not pwd:
            self.dlg.feedback.setText("⚠️ Error: Password cannot be empty!")
            self.dlg.feedback.setStyleSheet("color: red; font-weight: bold;")
            return

        try:
            self.inject_macros(pwd)
            self.dlg.feedback.setText("✅ Success! Macros injected.\nSave and reopen the project.")
            self.dlg.feedback.setStyleSheet("color: green; font-weight: bold;")
            self.dlg.apply_btn.setEnabled(False) # Prevent double injection
        except Exception as e:
            self.dlg.feedback.setText(f"❌ Error: {str(e)}")
            self.dlg.feedback.setStyleSheet("color: red; font-weight: bold;")

    def inject_macros(self, chosen_password):
        project = QgsProject.instance()
        
        macro_template = r"""from qgis.PyQt.QtWidgets import (QListWidget, QInputDialog, QLineEdit, 
                                 QApplication, QMessageBox, QWidget, 
                                 QVBoxLayout, QLabel, QPushButton)
from qgis.PyQt.QtCore import QTimer, QObject

class FunctionBlocker(QObject):
    def __init__(self):
        super().__init__()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.scan_for_dialog)
        self.timer.start(1000)

    def scan_for_dialog(self):
        for widget in QApplication.topLevelWidgets():
            if "QgsVectorLayerProperties" in widget.metaObject().className():
                if not widget.property("protection_armed"):
                    self.secure_tab(widget)

    def secure_tab(self, dialog):
        list_widget = dialog.findChild(QListWidget, "mOptionsListWidget")
        stacked_widget = dialog.findChild(QWidget, "mOptionsStackedWidget")
        if not list_widget or not stacked_widget: return

        target_index = -1
        targets = ["Attributformular", "Attributes Form", "Formulaire d'attributs", "Formulaire d’attributs", "Attributenformulier", "Attribuutformulier"]
        for i in range(list_widget.count()):
            if list_widget.item(i).text() in targets:
                target_index = i
                break
        
        if target_index != -1:
            lock_screen = QWidget()
            layout = QVBoxLayout()
            label = QLabel("<h2>Access Restricted</h2><p>This section is password protected.</p>")
            btn = QPushButton("Unlock Settings")
            layout.addWidget(label)
            layout.addWidget(btn)
            lock_screen.setLayout(layout)
            lock_index = stacked_widget.addWidget(lock_screen)
            
            list_widget.currentRowChanged.connect(
                lambda row: self.redirect(row, target_index, lock_index, stacked_widget, dialog)
            )
            btn.clicked.connect(lambda: self.attempt_unlock(dialog, stacked_widget, target_index))
            dialog.setProperty("protection_armed", True)
            dialog.setProperty("is_unlocked", False)

    def redirect(self, row, target_index, lock_index, stacked_widget, dialog):
        if row == target_index and not dialog.property("is_unlocked"):
            stacked_widget.setCurrentIndex(lock_index)

    def attempt_unlock(self, dialog, stacked_widget, target_index):
        pw, ok = QInputDialog.getText(dialog, "Auth", "Password:", QLineEdit.Password)
        if ok and pw == "{password_placeholder}":
            dialog.setProperty("is_unlocked", True)
            stacked_widget.setCurrentIndex(target_index)
        elif ok:
            QMessageBox.warning(dialog, "Error", "Wrong Password")

blocker = None
def openProject():
    global blocker
    blocker = FunctionBlocker()

def closeProject():
    global blocker
    if blocker: blocker.timer.stop(); blocker = None
"""
        # Replace the placeholder with the user's password
        final_macro = macro_template.replace("{password_placeholder}", chosen_password)
        
        # CORRECTED METHOD NAME:
        project.writeEntry("Macros", "pythonCode", final_macro)